from django.contrib import admin
from calorieapp.models import *
from calorieapp.models import Food,Consume
# Register your models here.
admin.site.register(Employee)
admin.site.register(Food)
admin.site.register(Consume)