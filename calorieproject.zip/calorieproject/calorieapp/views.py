from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from calorieapp.models import *
from django.contrib import messages
from django.contrib.auth.models import User,auth
from .models import Food,Consume



#def home(request):
#	return render(request,'home.html')





def input(request):
    return render(request,'input.html')

def empinput(request):
    return render(request,'empinput.html')

@csrf_exempt
def empsave(request):
    a=request.POST.get("sname")
    b=request.POST.get("scity")
    d=request.POST.get("semail")
    obj=Employee(name=a,city=b,email=d)
    obj.save()
    return HttpResponse("saved")

def empshow(request):
    obj=Employee.objects.all()
    msg="Data is <br>"
    for res in obj:
        msg=msg+"<br>"
        msg=msg+"name"+res.name+"<br>"
        msg=msg+"city"+res.city+"<br>"
        msg=msg+"email"+res.email+"<br>"
    return HttpResponse(msg)

def empfind(request):
    return render(request,'empfind.html')

@csrf_exempt
def finddata(request):
    a=request.POST.get("sname")
    obj=Employee.objects.filter(name=a)
    msg="Data is<br>"
    for res in obj:
        msg=msg+"<br>"
        msg=msg+"name"+res.name+"<br>"
        msg=msg+"city"+res.city+"<br>"
        msg=msg+"email"+res.email+"<br>"
    return HttpResponse(msg)

def empdelete(request):
    return render(request,'empdelete.html')

@csrf_exempt
def edelete(request):
    a=request.POST.get("sname")
    obj=Employee.objects.get(name=a)
    obj.delete()
    return HttpResponse("Deleted")

def empupdate(request):
    return render(request,'empupdate.html')

@csrf_exempt
def eupdate(request):
    a=request.POST.get("sname")
    b=request.POST.get("scity")
    d=request.POST.get("semail")
    obj=Employee.objects.get(name=a)
    obj.city=b
    obj.email=d
    obj.save()
    return HttpResponse("updated")






def mainscreen(request):
    return render(request, 'mainscreen.html')
def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email =request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        if password==confirm_password:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Email is exist ')
                return redirect(register) 
            else:
                user = User.objects.create_user(username=username,password=password, email=email, first_name=first_name, last_name=last_name) 
                user.set_password(password) 
                user.save()
                print("success")
                return redirect('login_user') 
        else:
            messages.info(request, 'Both passwords are not matching')
            return redirect(register)
    else:
        print("no post method")
        return render(request, 'register.html')



def login_user(request):
    if request.method == 'POST':
        username =request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return render(request,'homepage.html')
        else:
            messages.info(request, 'Invalid Username or Password')
            return redirect('login_user')
    else:
        return render(request, 'login.html')

def logout_user(request):
    auth.logout(request)
    return render(request,'mainscreen.html')





def bmi(request):
    return render(request,'bmi.html')

def bmr(request):
    return render(request,'bmr.html')


def index(request):

    if request.method == "POST":
        food_consumed = request.POST['food_consumed']
        consume = Food.objects.get(name=food_consumed)
        user = request.user
        consume = Consume(user=user, food_consumed=consume)
        consume.save()
        foods = Food.objects.all()

    else:
        foods = Food.objects.all()
    consumed_food = Consume.objects.filter(user=request.user)

    return render(request, 'index.html', {'foods': foods, 'consumed_food': consumed_food})


def delete_consume(request, id):
    consumed_food = Consume.objects.get(id=id)
    if request.method == 'POST':
        consumed_food.delete()
        return redirect('/')
    return render(request, 'delete.html')



def homepage(request):
    return render(request,'homepage.html')

def chech(request):
    return render(request,'chech.html')

def check(request):
    return render(request,'check.html')
